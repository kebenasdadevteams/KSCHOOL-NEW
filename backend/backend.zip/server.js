// backend/server.js
require('dotenv').config();
const app = require('./app');
const { testConnection, pool } = require('./config/db');

const PORT = Number(process.env.PORT) || 5000;

function startServer() {
  const server = app.listen(PORT, () => {
    console.log(`🚀 K-School API running on port ${PORT}`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  }).on('error', async (err) => {
    console.error('Server startup error:', err);
    process.exit(1);
  });
  return server;
}

async function ensureRequiredTables() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS youtube_archives (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(300) NOT NULL,
        speaker VARCHAR(200) NOT NULL,
        description TEXT,
        youtube_url VARCHAR(500) NOT NULL,
        channel_name VARCHAR(200),
        channel_url VARCHAR(500),
        category ENUM('live', 'featured', 'serious', 'theme') NOT NULL DEFAULT 'featured',
        badge VARCHAR(100) DEFAULT 'Featured',
        duration VARCHAR(50) DEFAULT 'Playlist',
        thumbnail_url VARCHAR(500),
        is_featured BOOLEAN DEFAULT FALSE,
        is_archived BOOLEAN DEFAULT FALSE,
        sort_order INT DEFAULT 0,
        created_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
      )
    `);

    console.log('✅ Required database tables verified');
  } catch (err) {
    console.error('❌ Failed to initialize required database tables:', err.message);
    throw err;
  }
}

async function boot() {
  // Test database connection
  await testConnection();
  console.log('✅ Database connected successfully');

  await ensureRequiredTables();

  // Start the server
  startServer();

  // Background scheduler: publish scheduled devotionals
  const checkScheduled = async () => {
    try {
      // Check if devotionals table exists first
      const [tables] = await pool.query(
        "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'devotionals'"
      );
      
      if (tables.length === 0) {
        // Table doesn't exist yet, skip silently
        return;
      }

      // Repair rows that were accidentally published before their scheduled time.
      await pool.query(`
        UPDATE devotionals
        SET status = 'scheduled',
            published_at = NULL,
            is_featured_today = FALSE,
            updated_at = NOW()
        WHERE status = 'published'
          AND publish_at IS NOT NULL
          AND publish_at > NOW()
      `);

      // Get scheduled devotionals that are due
      const [rows] = await pool.query(
        `SELECT id, title, publish_at FROM devotionals 
         WHERE status = 'scheduled' 
         AND publish_at IS NOT NULL 
         AND publish_at <= NOW()`
      );
      
      if (rows.length > 0) {
        console.log(`📅 Found ${rows.length} scheduled devotional(s) to publish`);
        
        for (const r of rows) {
          // Unset previous featured
          await pool.query('UPDATE devotionals SET is_featured_today = FALSE WHERE is_featured_today = TRUE');
          
          // Publish the scheduled devotional
          await pool.query(
            `UPDATE devotionals 
             SET status = 'published', 
                 published_at = NOW(), 
                 is_featured_today = TRUE,
                 updated_at = NOW()
             WHERE id = ?`,
            [r.id]
          );
          
          console.log(`✅ Published scheduled devotional #${r.id}: "${r.title || 'Untitled'}" at ${new Date().toISOString()}`);
          console.log(`   Scheduled for: ${r.publish_at}`);
        }
      }
    } catch (err) {
      // Only log if it's a real error (not "table doesn't exist")
      if (err.code !== 'ER_NO_SUCH_TABLE') {
        console.error('❌ Scheduler error:', err.message);
      }
    }
  };

  // Run immediately and then every 30 seconds
  console.log('⏰ Scheduler started - checking for scheduled devotionals every 30 seconds');
  
  // Initial check
  await checkScheduled();
  
  // Set interval
  const intervalId = setInterval(checkScheduled, 30 * 1000);

  // Graceful shutdown
  const shutdown = () => {
    console.log('\n🛑 Shutting down gracefully...');
    clearInterval(intervalId);
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err.message);
  console.error(err.stack);
  // Don't exit the process, just log the error
});

// Handle unhandled rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err.message);
  console.error(err.stack);
  // Don't exit the process, just log the error
});

// Start the application
boot().catch((err) => {
  console.error('❌ Failed to start application:', err.message);
  console.error(err.stack);
  process.exit(1);
});